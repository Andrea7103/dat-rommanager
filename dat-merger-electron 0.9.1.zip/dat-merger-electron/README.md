# DAT//ROMMANAGER

> Universal DAT Management Toolkit for ROM preservation — v0.9.1

A modern desktop application for managing, inspecting and processing DAT files used by ROM managers like **RomVault**, **ClrMamePro** and **RomCenter**.  
Built with Electron — runs on Windows, macOS and Linux.

---

## Modules

| # | Module | Status | Description |
|---|--------|--------|-------------|
| 01 | **DAT Merger** | ✅ READY | Merge hundreds of DAT files into a single file |
| 02 | **DAT Explorer** | ✅ READY | Browse DAT entries, inspect ROM details and system info |
| 03 | **DAT Splitter** | ✅ READY | Split a DAT by region, language, year, alphabet and more |
| 04 | **DAT Diff** | ✅ READY | Compare two DAT files — find unique and common entries |
| 05 | **DAT Generator** | ✅ READY | Generate a DAT from a ROM folder or emulator EXE output |
| 06 | **Checksum Calc** | ✅ READY | Compute CRC32 / MD5 / SHA1 / SHA256 for any file |

---

## Download

Grab the latest release for your platform:

| Platform | File |
|----------|------|
| 🪟 Windows | `.exe` installer |
| 🍎 macOS | `.dmg` package |
| 🐧 Linux | `.AppImage` |

👉 **[Latest Release](https://github.com/Andrea7103/dat-rommanager/releases/latest)**

---

## Features

- **DAT Merger** — drag and drop a folder of DATs, merge into one in seconds. Supports Logiqx XML and ClrMamePro formats.
- **DAT Explorer** — virtual scroll for 100k+ entries, live search, ROM detail view, system identification with 60+ systems database.
- **DAT Splitter** — 10 split modes (region, language, year, decade, alphabet, manufacturer, category, type, status, ROM count). Multi-mode composite splits supported.
- **DAT Diff** — compare DATs by CRC32 + SHA1 fingerprint (name-agnostic). A vs B mode and Master + N mode. Virtual scroll for 40,000+ entries. Export by category.
- **DAT Generator** — generate a Logiqx XML DAT from a ROM folder (CRC32 + MD5 + SHA1 via streaming) or from an emulator EXE (MAME, HBMAME, FBNeo, PinMAME and more). Real-time verbose console.
- **Checksum Calc** — drag any file, get CRC32 / MD5 / SHA1 / SHA256. Hash verify included. Export results as DAT.

---

## Supported DAT Formats

- **Logiqx XML** — No-Intro, Redump, TOSEC, MAME
- **ClrMamePro** `.dat` — legacy and modern
- Standard `.xml` ROM database files

Compatible with: RomVault · ClrMamePro · RomCenter

---

## Build from Source

**Prerequisites:** Node.js 18+ · npm

```bash
git clone https://github.com/Andrea7103/dat-rommanager.git
cd dat-rommanager
npm install
npm start
```

**Build installers:**
```bash
npm run build-win    # Windows .exe
npm run build-mac    # macOS .dmg
npm run build-linux  # Linux .AppImage
```

---

## Changelog

### v0.9.1 — August 2026
- **Module 05 — DAT Generator (NEW):** generate DAT from ROM folder scan with CRC32 + MD5 + SHA1 via streaming
- **Module 05 — DAT Generator:** generate DAT from emulator EXE output — auto-detects MAME, HBMAME, FBNeo, PinMAME, MESS, GroovyMAME, Raine, Nebula
- **Module 05 — DAT Generator:** real-time verbose console with progress bar
- **Module 04 — DAT Diff:** virtual scroll for instant tab switching with 40,000+ entries
- **Module 04 — DAT Diff:** fixed list not rendering after COMPARE
- **Module 04 — DAT Diff:** fixed entries with no dumped ROMs (device/slot placeholders) overwriting each other during comparison
- **Bug fix:** DAT Diff, Explorer Fix & Export, and Checksum export buttons now actually write the file to disk and report real success/failure (previously always reported success without saving)
- **Bug fix:** exported DAT paths now use proper cross-platform path handling — export no longer silently breaks on macOS/Linux
- **Bug fix:** DAT Generator — emulator arguments with quoted paths (spaces) no longer get split incorrectly
- **Bug fix:** DAT Generator — a failed emulator process is now reported as an error instead of silently producing an empty DAT
- **Bug fix:** DAT Generator — duplicate filenames across subfolders no longer produce duplicate game names in the generated DAT
- **UI:** redesigned typography for readability — body text now uses a clean sans-serif font, with the retro terminal fonts kept only for headers, icons and large stat displays
- **UI:** improved text contrast throughout the app
- All modules promoted to READY

### v0.9.0 — March 2026 · First public release
- DAT Merger, Explorer, Splitter, Checksum Calculator — stable
- GitHub Actions CI/CD for Windows, macOS and Linux builds
- Built-in documentation viewer and update notifier

---

## Roadmap

- [x] DAT Merger
- [x] DAT Explorer
- [x] DAT Splitter
- [x] DAT Diff
- [x] DAT Generator
- [x] Checksum Calculator
- [ ] DAT Generator — additional emulator profiles
- [ ] Explorer Fix & Export — repair malformed DATs inline

---

## Credits

**Author:** Andrea Luca Bozzalla ([@Andrea7103](https://github.com/Andrea7103))  
**AI Pair Programming:** Claude (Anthropic AI)

Special thanks: Simone73 · Mamechannel.it · Ricky74 · Vankraus · Napalm · Walter68 · Fava

---

Built with ❤️ for the ROM preservation community.
